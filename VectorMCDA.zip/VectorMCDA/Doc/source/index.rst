.. VectoMCDA documentation master file, created by
   sphinx-quickstart on Tue Aug 25 23:55:47 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to VectoMCDA's documentation!
=====================================

Contents:

.. toctree::
   :maxdepth: 2
   
    manual



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

